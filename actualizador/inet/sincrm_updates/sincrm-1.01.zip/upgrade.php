<?
mail('you@yourdomain.com', 'Your Site Was Upgraded', 'Your site has been upgraded to v'.$aV.'.');
?>